
Frequen_XCI<-function(ped,trait_missing=NA,allele_missing=0,ped.header=F,
					trait_type='quantitative',
					covariate=NULL,covariate.header=F,covariate_missing=NA){

library(rootSolve)

  if(!is.null(covariate)){

    if(is.character(covariate) & is.null(dim(covariate))) {

      covariatefile <- covariate

      id_covariate <- read.table(covariatefile,header=covariate.header,as.is=T)

      covariate_name <- colnames(id_covariate)[6:ncol(id_covariate)]

      colnames(id_covariate) <- c('famid','iid','father','mother','sex',covariate_name)

    }else if(is.data.frame(covariate) | is.matrix(covariate)) {

        id_covariate <- as.matrix(covariate)

        covariate_name <- paste('covariate',1:(ncol(id_covariate)-5),sep='_')

        colnames(id_covariate) <- c('famid','iid','father','mother','sex',covariate_name)
        
    }

    n_covariate <- ncol(id_covariate)-5

    if(!is.na(covariate_missing)){  

      for(i in 1:n_covariate){

       id_covariate[which(id_covariate[,i] == covariate_missing),i] <- NA		

      }
    }
  }


# read in pedigree file if it is provided

  marker.name <- NULL

  if (is.character(ped)&is.null(dim(ped))&ped.header) {

    pedfile <- ped

    ped <- read.table(pedfile,header=ped.header,as.is=T)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    marker.name <- colnames(ped)[5+2*(1:n.loci)]

    colnames(ped)<-c('famid','iid','father','mother','sex',colnames(ped)[6:dim(ped)[2]])

  }else if (is.character(ped)&is.null(dim(ped))& !ped.header) {

    pedfile <- ped

    ped <- read.table(pedfile,header=ped.header,as.is=T)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    marker.name <- paste('snp',1:n.loci,sep='_')

    snp.name_1 <- paste(marker.name,'1',sep='_')
    snp.name_2 <- paste(marker.name,'2',sep='_')

    snp.name <- character(2*n.loci)

    for(l in 1:(n.loci*2) ){

      snp.name[l] <- switch(l%%2+1,snp.name_2[l/2],snp.name_1[(l+1)/2])
    }

    colnames(ped) <- c('famid','iid','father','mother','sex','y',snp.name)

  }else if(is.data.frame(ped)|is.matrix(ped)) {

    ped <- as.matrix(ped)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    if(colnames(ped)[6]!='V6'){

      colnames(ped) <- c('famid','iid','father','mother','sex',colnames(ped)[6:ncol(ped)])

      marker.name <- colnames(ped)[5+2*(1:n.loci)] 

    }else if(colnames(ped)[6]=='V6'){

      marker.name <- paste('snp',1:n.loci,sep='_')

      snp.name_1 <- paste(marker.name,'1',sep='_')
      snp.name_2 <- paste(marker.name,'2',sep='_')

      snp.name <- character(2*n.loci)

      for(l in 1:(n.loci*2) ){

        snp.name[l]<-switch(l%%2+1,snp.name_2[l/2],snp.name_1[(l+1)/2])
        }

      colnames(ped) <- c('famid','iid','father','mother','sex','y',snp.name)
    }
  }

  ped <- as.matrix(ped)
  
  if(!is.na(trait_missing)){
  
  	ped[which(ped[,6] == trait_missing),6] <- NA	
  
   }

# merge ped and covariate if covariate is available

  if(!is.null(covariate)){

	merge_data <- merge(ped,id_covariate,all=T)

	ped <- merge_data[,1:ncol(ped)]

	covariate <- merge_data[,(ncol(ped)+1):ncol(merge_data)]
  }
	


# for each loci
 
  fiegamma_hat<-NA
  pengamma_hat<-NA
  rL_PenFieller<-NA
  rU_PenFieller<-NA
  rL_Fieller<-NA
  rU_Fieller<-NA
  IDP_F<-NA

  for(i in 1:n.loci){
	
	j <- 2*i+5

	if(!is.na(allele_missing)){  

		ped[which(ped[,j] == allele_missing),j] <- NA	

		ped[which(ped[,j+1] == allele_missing),j+1] <- NA	

		}

	if(!is.null(covariate)){

		data <- na.omit(cbind(ped[,c(6,j,j+1)],covariate))

		data <-matrix(as.numeric(as.matrix(data)),dim(data)[1])

		COV <- as.matrix(data[,4:ncol(data)])

	}else{

		data <- na.omit(ped[,c(6,j,j+1)])
	
		data <- matrix(as.numeric(data),dim(data)[1])
	}

	N<-dim(data)[1]

  	if(trait_type == 'qualitative'){data[,1] <- data[,1] - 1}

	genotype <- data[,2]+data[,3]-2

	x1 <- c(1*(genotype!=0)); x2 <- c(1*(genotype==2))

	if(is.null(covariate)){

		data <- list( y=data[,1], x1=x1, x2=x2)	

	}else{

		data <- list( y=data[,1], x1=x1, x2=x2)

		for(v in 1:n_covariate){

				data <- c(data, list(COV[,v]))
		}

		names(data)<- c('y','x1','x2',covariate_name)
	}


# analysis data

  if (trait_type=='quantitative'){ 

	var0<-var(data$y[which(genotype==0)])

	var1<-var(data$y[which(genotype==1)])

	var2<-var(data$y[which(genotype==2)])

	weight <-NA

	for(w in 1: N){

		weight[w] <- switch(genotype[w]+1, 1/var0, 1/var1, 1/var2)

	}

	if(is.null(covariate)){

		model1 <- glm(y ~ x1+x2, data=data, family = gaussian(link = "identity"), weights=weight)

	}else if(!is.null(covariate)){

		equation_<-as.formula(paste('y ~ x1+x2',paste(covariate_name,collapse='+'),sep='+'))

		model1 <- glm( equation_, data=data, family = gaussian(link = "identity"), weights=weight)
   
	}

  }else if(trait_type=='qualitative'){

	if(is.null(covariate)){

		model1 <- glm(y ~ x1+x2, data=data, family = "binomial")

	}else if(!is.null(covariate)){

		equation_<-as.formula(paste('y ~ x1+x2',paste(covariate_name,collapse='+'),sep='+'))

		model1 <- glm( equation_, data=data, family = "binomial")
   
	}
  }

  betahat1 <- model1$coefficients[[2]]
  betahat2 <- model1$coefficients[[3]]

  fiegamma_hat[i] <- 2*betahat1/(betahat1+betahat2)

  if(is.na(fiegamma_hat[i])){ stop(paste("Can't obtain point estimate of ",marker.name[i],sep='')) }

  COV_model <- summary(model1)$cov.unscaled
  var1 <- COV_model[2, 2]
  var2 <- COV_model[3, 3]
  covariatear <- COV_model[2, 3]
  var <- 4*var1/(betahat1 + betahat2)^2 + 4*betahat1^2*(var1 + var2 + 2*covariatear)/(betahat1 + betahat2)^4 - 4*betahat1*(2*var1 + 2*covariatear)/(betahat1 + betahat2)^3

  nume <- 2*betahat1  
  deno <- betahat1+betahat2
  var_nume <- 4*var1
  var_deno <- var1+2*covariatear+var2
  covariate_nude <- 2*(var1+covariatear)
  rho <- covariate_nude/sqrt(var_nume*var_deno)


#PF method

  PF <- PenFieller(nume,deno,var_nume,var_deno,rho,con_level=0.95)

  pengamma_hat[i] <- PF$point_res
  rU_PenFieller[i] <- PF$PenFieller_Upper
  rL_PenFieller[i] <- PF$PenFieller_Lower

# correction of the CIs

  if((rL_PenFieller[i]<rU_PenFieller[i] & rU_PenFieller[i]<0) | (rL_PenFieller[i]>rU_PenFieller[i] & rL_PenFieller[i]>2 & rU_PenFieller[i]<0 & pengamma_hat[i]<rU_PenFieller[i])){rL_PenFieller[i]<-rU_PenFieller[i]<- -9
  } else if((rL_PenFieller[i]<rU_PenFieller[i] & rL_PenFieller[i]>2) | (rL_PenFieller[i]>rU_PenFieller[i] & rL_PenFieller[i]>2 & rU_PenFieller[i]<0 & pengamma_hat[i]>rL_PenFieller[i])){rL_PenFieller[i]<-rU_PenFieller[i]<- 9
  } else if(rL_PenFieller[i]>rU_PenFieller[i] & (rL_PenFieller[i]<0 | rU_PenFieller[i]>2)){rL_PenFieller[i]<-0;rU_PenFieller[i]<-2
  } else if((rL_PenFieller[i]<rU_PenFieller[i] & rL_PenFieller[i]<0 & rU_PenFieller[i]>0 & rU_PenFieller[i]<2) | (rL_PenFieller[i]>rU_PenFieller[i] & rL_PenFieller[i]>2 & rU_PenFieller[i]>0 & rU_PenFieller[i]<2)){rL_PenFieller[i]<-0  
  } else if((rL_PenFieller[i]<rU_PenFieller[i] & rU_PenFieller[i]>2 & rL_PenFieller[i]>0 & rL_PenFieller[i]<2) | (rL_PenFieller[i]>rU_PenFieller[i] & rU_PenFieller[i]<0 & rL_PenFieller[i]>0 & rL_PenFieller[i]<2)){rU_PenFieller[i]<-2  
  }


# Fieller method

  A_Fieller <- deno^2-qchisq(1-0.05,1)*var_deno  
  B_Fieller <- 2*(qchisq(1-0.05,1)*covariate_nude-nume*deno)
  C_Fieller <- nume^2-qchisq(1-0.05,1)*var_nume

  delta_Fieller <- B_Fieller^2-4*A_Fieller*C_Fieller

  IDP_F[i]<-0                                      # 0-continuous  1-discontinuous

  if(A_Fieller != 0){

    if(delta_Fieller > 0){                          # two roots

      if(A_Fieller > 0){                            # continuous CI

        rL_Fieller[i] <- (-B_Fieller-sqrt(delta_Fieller))/(2*A_Fieller)
        rU_Fieller[i] <- (-B_Fieller+sqrt(delta_Fieller))/(2*A_Fieller)

      } else{                                       # A < 0 leads to rL_Fieller>rU_Fieller which breaks CI

        rL_Fieller[i] <- (-B_Fieller-sqrt(delta_Fieller))/(2*A_Fieller)
        rU_Fieller[i] <- (-B_Fieller+sqrt(delta_Fieller))/(2*A_Fieller)

        IDP_F[i]<-1                                 #IDP_F = 1 indicates discontinuous CI
      }

    } else if(delta_Fieller == 0){                  # one root

      	rL_Fieller[i] <- rU_Fieller[i] <- -B_Fieller/(2*A_Fieller)

    } else{                                         # delta_Fieller < 0 CI has no limit

		if(A_Fieller < 0){rL_Fieller[i] <- -9; rU_Fieller[i] <- 9} 
    }

  } else{                                            # A_Fieller = 0

		rL_Fieller[i] <- rU_Fieller[i] <- -C_Fieller/B_Fieller

  }
  

# correction of the CIs

    if((rL_Fieller[i]<rU_Fieller[i] & rU_Fieller[i]<0) | (rL_Fieller[i]>rU_Fieller[i] & rL_Fieller[i]>2 & rU_Fieller[i]<0 & fiegamma_hat[i]<rU_Fieller[i])){rL_Fieller[i]<-rU_Fieller[i]<- -9;IDP_F[i]<-0
  } else if((rL_Fieller[i]<rU_Fieller[i] & rL_Fieller[i]>2) | (rL_Fieller[i]>rU_Fieller[i] & rL_Fieller[i]>2 & rU_Fieller[i]<0 & fiegamma_hat[i]>rL_Fieller[i])){rL_Fieller[i]<-rU_Fieller[i]<- 9;IDP_F[i]<-0
  } else if(rL_Fieller[i]>rU_Fieller[i] & (rL_Fieller[i]<0 | rU_Fieller[i]>2)){rL_Fieller[i]<-0;rU_Fieller[i]<-2;IDP_F[i]<-0
  } else if((rL_Fieller[i]<rU_Fieller[i] & rL_Fieller[i]<0 & rU_Fieller[i]>0 & rU_Fieller[i]<2) | (rL_Fieller[i]>rU_Fieller[i] & rL_Fieller[i]>2 & rU_Fieller[i]>0 & rU_Fieller[i]<2)){rL_Fieller[i]<-0;IDP_F[i]<-0
  } else if((rL_Fieller[i]<rU_Fieller[i] & rU_Fieller[i]>2 & rL_Fieller[i]>0 & rL_Fieller[i]<2) | (rL_Fieller[i]>rU_Fieller[i] & rU_Fieller[i]<0 & rL_Fieller[i]>0 & rL_Fieller[i]<2)){rU_Fieller[i]<-2;IDP_F[i]<-0
  }

 }


	fiegamma_res<-0*(fiegamma_hat<0)+fiegamma_hat*(0<=fiegamma_hat & fiegamma_hat<=2)+2*(fiegamma_hat>2)
	pengamma_res<-0*(pengamma_hat<0)+pengamma_hat*(0<=pengamma_hat & pengamma_hat<=2)+2*(pengamma_hat>2)

	rL_Fieller_res<-0*(rL_Fieller<0)+rL_Fieller*(0<=rL_Fieller & rL_Fieller<=2)+2*(rL_Fieller>2)
	rU_Fieller_res<-0*(rU_Fieller<0)+rU_Fieller*(0<=rU_Fieller & rU_Fieller<=2)+2*(rU_Fieller>2)
	
	rL_PenFieller_res<-0*(rL_PenFieller<0)+rL_PenFieller*(0<=rL_PenFieller & rL_PenFieller<=2)+2*(rL_PenFieller>2)
	rU_PenFieller_res<-0*(rU_PenFieller<0)+rU_PenFieller*(0<=rU_PenFieller & rU_PenFieller<=2)+2*(rU_PenFieller>2)

	result <- cbind(fiegamma_res, rL_Fieller_res, rU_Fieller_res, IDP_F, pengamma_res, rL_PenFieller_res, rU_PenFieller_res)

	row.names(result) <- marker.name

	colnames(result) <- c("F_Point_Estimate","F_Lower","F_Upper","F_discontinuous","PF_Point_Estimate","PF_Lower","PF_Upper")

	return(result)

}





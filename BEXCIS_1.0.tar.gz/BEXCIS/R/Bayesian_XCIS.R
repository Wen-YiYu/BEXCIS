
# HPDI function

HPDIofHMC = function( sampleVec , credMass=0.95 ) {
  sortedsam = sort( sampleVec )
  nsamp <- length( sortedsam )
  gap = round( credMass * nsamp )
  nCIs = nsamp - gap
  init <- 1 : nCIs
  inds <- which.min(sortedsam[init + gap] - sortedsam[init])
  HPDImin = sortedsam[ inds ]
  HPDImax = sortedsam[ inds + gap ]
  HPDIlim = c( HPDImin , HPDImax )
  return( HPDIlim )
}

# mode function

modeofHMC <- function(samples){
  dd <- density(samples)
  dd$x[which.max(dd$y)]
}


# Bayesian function

Bayes_XCI<-function(ped, trait_missing=NA, allele_missing=0, ped.header=F, trait_type='quantitative', covariate=NULL,
					covariate_prior=NULL, covariate_missing=NA, covariate_prior_limit=NULL, covariate.header=F,
					gamma_prior='normal', chains_num=8, total_sample=20000, warmup_sample=10000, adapt_delta_value=0.99){

  library(rstan) 
  options(mc.cores = parallel::detectCores())
  rstan_options(javascript = FALSE)
  rstan_options(auto_write = TRUE)

  if(!is.null(covariate)){

    if(is.character(covariate) & is.null(dim(covariate))) {

      covariatefile <- covariate

      id_covariate <- read.table(covariatefile,header=covariate.header,as.is=T)

      covariate_name <- paste('covariate',1:(ncol(id_covariate)-5),sep='_') 

      colnames(id_covariate) <- c('famid','iid','father','mother','sex',covariate_name)

    }else if(is.data.frame(covariate) | is.matrix(covariate)) {

        id_covariate <- as.matrix(covariate)

        covariate_name <- paste('covariate',1:(ncol(id_covariate)-5),sep='_')

        colnames(id_covariate) <- c('famid','iid','father','mother','sex',covariate_name)
     }

    n_covariate <- ncol(id_covariate)-5

    if( is.null(covariate_prior) ){

      stop("Please provide prior distributions for the covariates")}

    if( n_covariate!=nrow(covariate_prior) ){

      stop("Numbers of covariates and their prior distributions don't match")}

    if(!is.na(covariate_missing)){  

      for(i in 1:n_covariate){

       id_covariate[which(id_covariate[,i] == covariate_missing),i] <- NA		

      }
    }
  }

# read in pedigree file if it is provided

  marker.name <- NULL

  if (is.character(ped)&is.null(dim(ped))&ped.header) {

    pedfile <- ped

    ped <- read.table(pedfile,header=ped.header,as.is=T)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    marker.name <- colnames(ped)[5+2*(1:n.loci)]

    colnames(ped)<-c('famid','iid','father','mother','sex',colnames(ped)[6:ncol(ped)])

  }else if (is.character(ped)&is.null(dim(ped))& !ped.header) {

    pedfile <- ped

    ped <- read.table(pedfile,header=ped.header,as.is=T)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    marker.name <- paste('snp',1:n.loci,sep='_')

    snp.name_1 <- paste(marker.name,'1',sep='_')
    snp.name_2 <- paste(marker.name,'2',sep='_')

    snp.name <- character(2*n.loci)

    for(l in 1:(n.loci*2) ){

      snp.name[l] <- switch(l%%2+1,snp.name_2[l/2],snp.name_1[(l+1)/2])
    }

    colnames(ped) <- c('famid','iid','father','mother','sex','y',snp.name)

  }else if(is.data.frame(ped)|is.matrix(ped)) {

    ped <- as.matrix(ped)

    ped <- ped[which(ped[,3]==0 & ped[,5]==2),]

    n.loci <- (dim(ped)[2] - 6) / 2

    n.ind <- dim(ped)[1]

    if(colnames(ped)[6]!='V6'){

      colnames(ped)<-c('famid','iid','father','mother','sex',colnames(ped)[6:ncol(ped)])

      marker.name <- dimnames(ped)[[2]][5+2*(1:n.loci)] 

    }else if(colnames(ped)[6]=='V6'){

      marker.name <- paste('snp',1:n.loci,sep='_')

      snp.name_1 <- paste(marker.name,'1',sep='_')
      snp.name_2 <- paste(marker.name,'2',sep='_')

      snp.name <- character(2*n.loci)

      for(l in 1:(n.loci*2) ){

        snp.name[l]<-switch(l%%2+1,snp.name_2[l/2],snp.name_1[(l+1)/2])
        }

      colnames(ped) <- c('famid','iid','father','mother','sex','y',snp.name)
    }
  }

  ped <- as.matrix(ped)
  
  if(!is.na(trait_missing)){
  
  	ped[which(ped[,6] == trait_missing),6] <- NA	
  
   }

# merge ped and covariate if covariate is available

  if(!is.null(covariate)){

	merge_data <- merge(ped,id_covariate,all=T)

    merge_data1<-merge_data[order(merge_data[,1]),]

	ped <- merge_data1[,1:ncol(ped)]

	covariate <- merge_data1[,(ncol(ped)+1):ncol(merge_data1)]
  }
	

  if (is.null(marker.name)) {

      marker.name <- paste("snp",1:n.loci,sep='_')

  }



# for each loci

  if(!is.null(covariate)){

    covariate_parameters_code <- character(n_covariate)
  }

  Mode_gamma <- NULL
  HPDI_gamma <- NULL 

  for(i in 1:n.loci){
	
	j <- 2*i+5

	if(!is.na(allele_missing)){  

		ped[which(ped[,j] == allele_missing),j] <- NA	

		ped[which(ped[,j+1] == allele_missing),j+1] <- NA	

		}

	if(!is.null(covariate)){

		data <- na.omit(cbind(ped[,c(6,j,j+1)],covariate))

		data<-matrix(as.numeric(as.matrix(data)),dim(data)[1])

		COV<-data[,4:ncol(data)]

	}else{

		data <- na.omit(ped[,c(6,j,j+1)])
	
		data<-matrix(as.numeric(data),dim(data)[1])
	}

	N<-dim(data)[1]

  	if(trait_type == 'qualitative'){data[,1] <- data[,1] - 1}

	genotype <- data[,2]+data[,3]-2

	x1 <- c(1*(genotype!=0)); x2 <- c(1*(genotype==2))

	if(is.null(covariate)){

		X <- cbind(x1,x2)

	}else{

		X <- cbind(x1,x2,COV)

	}

	if(trait_type == 'quantitative'){

		model_matrix <- cbind(rep(1,N),x1,x2)

		model_matrix[,1] <- model_matrix[,1] - model_matrix[,2]

		model_matrix[,2] <- model_matrix[,2] - model_matrix[,3]

		data <- list( y=data[,1], X=X, N=N, n_sigma=3, model_matrix=model_matrix )

	}else{

		data <- list( y=data[,1], X=X, N=N )

	}


# Bayesian model

	if(gamma_prior=='normal'){gammadis <- "target += normal_lpdf( gamma | 1, 1 )"

	}else if(gamma_prior=='uniform'){gammadis <- "target += uniform_lpdf( gamma | 0, 2 )"}


  if(!is.null(covariate)){

	for(c in 1:n_covariate){

		if(!is.na(covariate_prior_limit[c,1])& !is.na(covariate_prior_limit[c,2])){

		  covariate_parameters_code[c] <-paste('real<lower=',covariate_prior_limit[c,1],',','upper=',covariate_prior_limit[c,2],'>',sep='')

		}else if(!is.na(covariate_prior_limit[c,1])& is.na(covariate_prior_limit[c,2])){

		  covariate_parameters_code[c] <-paste('real<lower=',covariate_prior_limit[c,1],'>',sep='')

		}else if(is.na(covariate_prior_limit[c,1])& !is.na(covariate_prior_limit[c,2])){

		  covariate_parameters_code[c] <-paste('real<upper=',covariate_prior_limit[c,2],'>',sep='')

		}else if(is.na(covariate_prior_limit[c,1])& is.na(covariate_prior_limit[c,2])){

		  covariate_parameters_code[c] <-'real'

		}
		if((is.na(covariate_prior_limit[c,1])|as.numeric(covariate_prior_limit[c,1])<0)& is.na(covariate_prior_limit[c,2]) & covariate_prior[c,1]=='exponential'){

		  covariate_parameters_code[c] <- 'real<lower=0>'}

		if((is.na(covariate_prior_limit[c,1])|as.numeric(covariate_prior_limit[c,1])<0)& !is.na(covariate_prior_limit[c,2]) & covariate_prior[c,1]=='exponential'){

		  covariate_parameters_code[c] <- paste('real<lower=0,upper=',covariate_prior_limit[c,2],'>',sep='')
		}

	}
  }

  if (trait_type=='quantitative'){  

	data_definition <- paste("
		data {
			int<lower=0> N ;
			int<lower=0> n_sigma ;
			real y[N] ; 
			matrix[N,",dim(X)[2],"] X;
			matrix[N,n_sigma] model_matrix;
		}", sep='')

  if(!is.null(covariate)){

	parameters_definition <- paste("
		parameters {
			real beta0;
			real beta;\n",

			paste(paste(paste(covariate_parameters_code,'beta')[1:length(covariate_name)],covariate_name,sep='_')[1:length(covariate_name)],collapse=';\n'),

			";
			real<lower=0,upper=2> gamma;
			vector<lower=0>[n_sigma] sigma;
		}", sep='')

	model_definition <- paste("
		model {
		vector[N] theta;
		vector[N] sigma_heter;
		theta = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] +", 

		paste(

		paste( paste(paste("beta",covariate_name,sep='_'),"*",sep=''),

		paste(paste("X[,",2+(1:n_covariate),sep=''),"]",sep=''),sep=''),

		collapse='+'),

		";
		sigma_heter = model_matrix * sigma;
		target += normal_lpdf( beta0 | 0, 10 );      
		target += normal_lpdf( beta | 0, 10 );\n",

		paste(paste("target +=", covariate_prior[,1],

		paste(paste("_lpdf(beta",covariate_name,sep='_'),"|",sep=''),covariate_prior[,2],")",sep=''),

		collapse=';\n'),

		";\n",
		gammadis,";
		target += exponential_lpdf(sigma | 1);
		for(i in 1:N)
		target += normal_lpdf( y[i] | theta[i], sigma_heter[i] );
	}",sep='')

  }else if(is.null(covariate)){

	parameters_definition <- "
		parameters {
			real beta0;
			real beta;
			real<lower=0,upper=2> gamma;
			vector<lower=0>[n_sigma] sigma;
		}"

	model_definition <- paste("
		model {
		vector[N] theta;
		vector[N] sigma_heter;
		theta = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2];
		sigma_heter = model_matrix * sigma;
		target += normal_lpdf( beta0 | 0, 10 );      
		target += normal_lpdf( beta | 0, 10 );
		",
		gammadis,";
		target += exponential_lpdf(sigma | 1);
		for(i in 1:N)
		target += normal_lpdf( y[i] | theta[i], sigma_heter[i] );
	}",sep='')
}


  }else if (trait_type=='qualitative'){  

	data_definition <- paste("
		data {
			int<lower=0> N ;
			int y[N] ; 
			matrix[N,",dim(X)[2],"] X;
		}", sep='')


  if(!is.null(covariate)){

	parameters_definition <- paste("
		parameters {
			real beta0;
			real beta;\n",

			paste(paste(paste(covariate_parameters_code,'beta')[1:length(covariate_name)],covariate_name,sep='_')[1:length(covariate_name)],collapse=';\n'),

			";
			real<lower=0,upper=2> gamma;
		}", sep='')


	model_definition <- paste("
		model {
		vector[N] theta;
		theta = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] +", 

		paste(

		paste( paste(paste("beta",covariate_name,sep='_'),"*",sep=''),

		paste(paste("X[,",2+(1:n_covariate),sep=''),"]",sep=''),sep=''),

		collapse='+'),

		";
		target += normal_lpdf( beta0 | 0, 10 );      
		target += normal_lpdf( beta | 0, 10 );\n",

		paste(paste("target +=", covariate_prior[,1],

		paste(paste("_lpdf(beta",covariate_name,sep='_'),"|",sep=''),covariate_prior[,2],")",sep=''),

		collapse=';\n'),

		";\n",
		gammadis,";
		target += bernoulli_logit_lpmf( y | theta );
	}",sep='')

  }else if(is.null(covariate)){

	parameters_definition <- "
		parameters {
			real beta0;
			real beta;
			real<lower=0,upper=2> gamma;
		}"


	model_definition <- paste("
		model {
		vector[N] theta;
		theta = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2];
		target += normal_lpdf( beta0 | 0, 10 );      
		target += normal_lpdf( beta | 0, 10 );\n",
		gammadis,";
		target += bernoulli_logit_lpmf( y | theta );
	}",sep='')
	}
  }
	
	if(i==1){

      modelString_H1 <-paste(data_definition,parameters_definition,model_definition,sep='\n')

      stanDso_H1 <- stan_model( model_code=modelString_H1 )
    }

      tryCatch(Fit_H1 <- sampling( object=stanDso_H1, data=data, chains=chains_num,
							 iter=total_sample, warmup=warmup_sample, thin=1,
							control = list(adapt_delta = adapt_delta_value)),
		 warning = function(w) {print(marker.name[i])})

 	sam_chain <- extract( Fit_H1, par=c("gamma"))

	Mode_gamma <- c( Mode_gamma, modeofHMC(sam_chain$gamma) )
  
	HPDI_gamma <- rbind( HPDI_gamma , HPDIofHMC(sam_chain$gamma) )  

   
}
	result <- cbind(Mode_gamma, HPDI_gamma)

	row.names(result) <- marker.name

	colnames(result) <- c("Point_Estimate","HPDI_Lower","HPDI_Upper")

	return(result)

}




